"""
Simple News Chatbot Handler

AWS Lambda Powertools 의존성 없이 기본 라이브러리만 사용하는 버전입니다.
"""

import json
import logging
import os
import re
from datetime import datetime
from typing import Any, Dict, Optional, List
from urllib.parse import urlparse

import boto3
from botocore.exceptions import ClientError

# 환경 변수 설정
KNOWLEDGE_BASE_ID = os.environ.get("KNOWLEDGE_BASE_ID")
LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO")

# 로깅 설정
logger = logging.getLogger()
logger.setLevel(getattr(logging, LOG_LEVEL))

# AWS 클라이언트 초기화
bedrock_runtime = boto3.client("bedrock-runtime")
bedrock_agent_runtime = boto3.client("bedrock-agent-runtime")
s3_client = boto3.client("s3")


class ChatbotError(Exception):
    """챗봇 관련 사용자 정의 예외"""
    pass


def expand_query_with_ai(original_query: str) -> str:
    """AI를 사용하여 검색 질문을 확장합니다."""
    try:
        prompt = f"""다음 질문을 뉴스 검색에 더 적합하도록 확장해주세요. 
원본 질문: "{original_query}"

확장 규칙:
1. 기업명이 있으면 관련 계열사, 주요 사업 분야 추가
2. 경제 용어가 있으면 관련 키워드 추가  
3. 최대 3-4개의 관련 키워드만 추가
4. 한국 경제/기업 뉴스 맥락에서 확장

확장된 검색어만 출력하세요 (설명 없이):"""

        response = bedrock_runtime.invoke_model(
            modelId="anthropic.claude-3-haiku-20240307-v1:0",
            body=json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 100,
                "messages": [
                    {
                        "role": "user", 
                        "content": prompt
                    }
                ]
            })
        )
        
        result = json.loads(response['body'].read())
        expanded_query = result['content'][0]['text'].strip()
        
        logger.info(f"AI expanded query: '{original_query}' -> '{expanded_query}'")
        return expanded_query
        
    except Exception as e:
        logger.warning(f"Failed to expand query with AI: {str(e)}")
        return original_query


def retrieve_and_generate_with_references(query: str, max_results: int = 10) -> Dict[str, Any]:
    """Bedrock Knowledge Base에서 정보를 검색하고 답변을 생성합니다. References도 함께 반환합니다."""
    try:
        # AI를 사용하여 질문 확장
        expanded_query = expand_query_with_ai(query)
        
        logger.info(f"Querying knowledge base with expanded query: {expanded_query}")
        
        # 1. 먼저 retrieve로 references 가져오기
        retrieve_response = bedrock_agent_runtime.retrieve(
            knowledgeBaseId=KNOWLEDGE_BASE_ID,
            retrievalQuery={
                "text": expanded_query
            },
            retrievalConfiguration={
                "vectorSearchConfiguration": {
                    "numberOfResults": max_results,
                    "overrideSearchType": "HYBRID"
                }
            }
        )
        
        logger.info(f"Retrieved {len(retrieve_response.get('retrievalResults', []))} results from retrieve API")
        
        # 2. 그 다음 retrieveAndGenerate로 답변 생성
        generate_response = bedrock_agent_runtime.retrieve_and_generate(
            input={
                "text": expanded_query
            },
            retrieveAndGenerateConfiguration={
                "type": "KNOWLEDGE_BASE",
                "knowledgeBaseConfiguration": {
                    "knowledgeBaseId": KNOWLEDGE_BASE_ID,
                    "modelArn": "arn:aws:bedrock:ap-northeast-2::foundation-model/anthropic.claude-3-haiku-20240307-v1:0",
                    "retrievalConfiguration": {
                        "vectorSearchConfiguration": {
                            "numberOfResults": max_results,
                            "overrideSearchType": "HYBRID"
                        }
                    },
                    "generationConfiguration": {
                        "promptTemplate": {
                            "textPromptTemplate": """다음 뉴스 기사들을 참고하여 질문에 답변해주세요.

질문: $query$

뉴스 기사:
$search_results$

답변 작성 규칙:
1. 제공된 뉴스 기사의 정보만 사용하여 답변하세요
2. 중요한 정보나 수치를 언급할 때는 반드시 출처를 명시하세요
3. 각 문장 끝에 [1], [2] 형태의 각주 번호를 추가하세요
4. 정확하고 객관적인 정보만 제공하세요
5. 추측이나 개인적 의견은 포함하지 마세요

답변:"""
                        }
                    }
                }
            }
        )
        
        # 3. retrieve 결과를 generate 응답에 병합
        combined_response = generate_response.copy()
        
        # retrieve 결과를 citations에 추가
        if retrieve_response.get('retrievalResults'):
            # 기존 citations가 비어있다면 retrieve 결과로 새로 생성
            if not combined_response.get('citations') or not any(c.get('retrievedReferences') for c in combined_response.get('citations', [])):
                logger.info("Adding retrieve results to citations")
                citation_with_references = {
                    "generatedResponsePart": {
                        "textResponsePart": {
                            "span": {"start": 0, "end": len(combined_response.get('output', {}).get('text', ''))},
                            "text": combined_response.get('output', {}).get('text', '')
                        }
                    },
                    "retrievedReferences": []
                }
                
                # retrieve 결과를 retrievedReferences로 변환
                for retrieval_result in retrieve_response['retrievalResults']:
                    reference = {
                        "content": {
                            "text": retrieval_result.get('content', {}).get('text', '')
                        },
                        "location": retrieval_result.get('location', {}),
                        "metadata": retrieval_result.get('metadata', {})
                    }
                    citation_with_references["retrievedReferences"].append(reference)
                
                combined_response['citations'] = [citation_with_references]
                logger.info(f"Created new citation with {len(citation_with_references['retrievedReferences'])} references")
        
        logger.info("Successfully retrieved and generated response with references")
        
        # 디버깅: 전체 응답 구조 로깅
        logger.info(f"Final combined response structure: {json.dumps(combined_response, default=str, ensure_ascii=False)}")
        
        return combined_response
        
    except ClientError as e:
        error_code = e.response.get("Error", {}).get("Code", "Unknown")
        error_message = e.response.get("Error", {}).get("Message", "Unknown error")
        logger.error(f"Bedrock API error: {error_code} - {error_message}")
        raise ChatbotError(f"지식 기반 검색 중 오류가 발생했습니다: {error_message}")
    
    except Exception as e:
        logger.error(f"Unexpected error in retrieve_and_generate_with_references: {str(e)}")
        raise ChatbotError("답변 생성 중 예상치 못한 오류가 발생했습니다")


def validate_request_body(body: Dict[str, Any]) -> str:
    """요청 본문의 유효성을 검사하고 질문을 추출합니다."""
    if not isinstance(body, dict):
        raise ChatbotError("요청 본문은 JSON 객체여야 합니다")
    
    question = body.get("question", "").strip()
    if not question:
        raise ChatbotError("질문(question) 필드가 필요합니다")
    
    if len(question) > 1000:
        raise ChatbotError("질문은 1000자를 초과할 수 없습니다")
    
    return question


def add_footnotes_to_answer(answer: str, sources: List[Dict]) -> str:
    """답변에 각주 번호를 추가합니다."""
    if not sources:
        return answer
    
    # 이미 [숫자] 형태의 각주가 있는지 확인
    footnote_pattern = r'\[\d+\]'
    if re.search(footnote_pattern, answer):
        return answer  # 이미 각주가 있으면 그대로 반환
    
    # 문장 단위로 분할하여 각주 추가
    sentences = re.split(r'(?<=[.!?])\s+', answer)
    
    footnoted_answer = ""
    footnote_num = 1
    
    for i, sentence in enumerate(sentences):
        footnoted_answer += sentence
        
        # 각 문장마다 각주 추가 (최대 출처 수만큼)
        if footnote_num <= len(sources) and sentence.strip():
            footnoted_answer += f" [{footnote_num}]"
            footnote_num += 1
        
        if i < len(sentences) - 1:
            footnoted_answer += " "
    
    return footnoted_answer


def extract_metadata_from_s3(s3_uri: str) -> Dict[str, str]:
    """S3 URI에서 원본 .md 파일을 읽어 메타데이터를 추출합니다."""
    metadata = {
        "title": "",
        "date": "",
        "author": "",
        "media": "서울경제",
        "url": ""
    }
    
    try:
        # S3 URI 파싱 (s3://bucket-name/path/to/file.md)
        parsed_uri = urlparse(s3_uri)
        bucket_name = parsed_uri.netloc
        object_key = parsed_uri.path.lstrip('/')
        
        logger.info(f"Reading S3 file: bucket={bucket_name}, key={object_key}")
        
        # S3에서 파일 읽기
        response = s3_client.get_object(Bucket=bucket_name, Key=object_key)
        content = response['Body'].read().decode('utf-8')
        
        # .md 파일에서 기사들을 분리 (--- 구분자 사용)
        articles = content.split('\n---\n')
        
        # 첫 번째 실제 기사에서 메타데이터 추출 (헤더 부분 제외)
        if len(articles) > 1:
            first_article = articles[1]  # 첫 번째 기사
            
            # 제목 추출 - ### 숫자. 제목 패턴
            title_match = re.search(r'###\s*\d+\.\s*(.+?)(?:\n|$)', first_article)
            if title_match:
                metadata["title"] = title_match.group(1).strip()
            
            # 발행일 추출
            date_match = re.search(r'\*\*발행일:\*\*\s*([^\n]+)', first_article)
            if date_match:
                date_str = date_match.group(1).strip()
                # ISO 날짜를 한국어 형식으로 변환
                try:
                    # 2016-04-10T00:00:00.000+09:00 형식 처리
                    if 'T' in date_str:
                        dt = datetime.fromisoformat(date_str.replace('T00:00:00.000+09:00', ''))
                        metadata["date"] = dt.strftime('%Y년 %m월 %d일')
                    else:
                        metadata["date"] = date_str
                except:
                    metadata["date"] = date_str
            
            # 기자 추출
            author_match = re.search(r'\*\*기자:\*\*\s*([^\n]+)', first_article)
            if author_match:
                metadata["author"] = author_match.group(1).strip()
            
            # 언론사 추출
            media_match = re.search(r'\*\*언론사:\*\*\s*([^\n]+)', first_article)
            if media_match:
                metadata["media"] = media_match.group(1).strip()
            
            # URL 추출
            url_match = re.search(r'\*\*URL:\*\*\s*([^\n\s]+)', first_article)
            if url_match:
                metadata["url"] = url_match.group(1).strip()
            
            logger.info(f"Extracted metadata from S3: {metadata}")
        
    except Exception as e:
        logger.warning(f"Failed to extract metadata from S3 {s3_uri}: {str(e)}")
    
    return metadata


def find_best_matching_article(s3_uri: str, query_chunk: str) -> Dict[str, str]:
    """S3 파일에서 쿼리와 가장 관련성 높은 기사를 찾아 메타데이터를 추출합니다."""
    try:
        # S3 URI 파싱
        parsed_uri = urlparse(s3_uri)
        bucket_name = parsed_uri.netloc
        object_key = parsed_uri.path.lstrip('/')
        
        # S3에서 파일 읽기
        response = s3_client.get_object(Bucket=bucket_name, Key=object_key)
        content = response['Body'].read().decode('utf-8')
        
        # .md 파일에서 기사들을 분리
        articles = content.split('\n---\n')
        
        best_metadata = None
        max_relevance = 0
        
        # 각 기사에서 관련성 검사
        for i, article in enumerate(articles[1:], 1):  # 첫 번째는 헤더이므로 제외
            # 제목 추출
            title_match = re.search(r'###\s*\d+\.\s*(.+?)(?:\n|$)', article)
            title = title_match.group(1).strip() if title_match else ""
            
            # 기사 본문에서 쿼리 청크와의 관련성 계산
            relevance = 0
            query_words = set(query_chunk.lower().split())
            article_words = set(article.lower().split())
            
            # 단어 매칭으로 간단한 관련성 계산
            common_words = query_words.intersection(article_words)
            if query_words:
                relevance = len(common_words) / len(query_words)
            
            # 제목에 쿼리 키워드가 포함되면 가중치 추가
            if any(word in title.lower() for word in query_words):
                relevance += 0.3
            
            logger.info(f"Article {i} relevance: {relevance:.3f}, title: {title[:50]}...")
            
            if relevance > max_relevance:
                max_relevance = relevance
                
                # 해당 기사의 메타데이터 추출
                metadata = {
                    "title": title,
                    "date": "",
                    "author": "",
                    "media": "서울경제",
                    "url": ""
                }
                
                # 발행일 추출
                date_match = re.search(r'\*\*발행일:\*\*\s*([^\n]+)', article)
                if date_match:
                    date_str = date_match.group(1).strip()
                    try:
                        if 'T' in date_str:
                            dt = datetime.fromisoformat(date_str.replace('T00:00:00.000+09:00', ''))
                            metadata["date"] = dt.strftime('%Y년 %m월 %d일')
                        else:
                            metadata["date"] = date_str
                    except:
                        metadata["date"] = date_str
                
                # 기자 추출
                author_match = re.search(r'\*\*기자:\*\*\s*([^\n]+)', article)
                if author_match:
                    metadata["author"] = author_match.group(1).strip()
                
                # 언론사 추출
                media_match = re.search(r'\*\*언론사:\*\*\s*([^\n]+)', article)
                if media_match:
                    metadata["media"] = media_match.group(1).strip()
                
                # URL 추출
                url_match = re.search(r'\*\*URL:\*\*\s*([^\n\s]+)', article)
                if url_match:
                    metadata["url"] = url_match.group(1).strip()
                
                best_metadata = metadata
        
        logger.info(f"Best matching article metadata: {best_metadata}")
        return best_metadata or extract_metadata_from_s3(s3_uri)
        
    except Exception as e:
        logger.warning(f"Failed to find best matching article: {str(e)}")
        return extract_metadata_from_s3(s3_uri)


def handle_chat(event: Dict[str, Any]) -> Dict[str, Any]:
    """챗봇 대화 요청을 처리합니다."""
    try:
        # API Gateway 이벤트에서 본문 추출
        if 'body' in event:
            if isinstance(event['body'], str):
                request_body = json.loads(event['body'])
            else:
                request_body = event['body']
        else:
            request_body = event
            
        question = validate_request_body(request_body)
        
        logger.info(f"Processing chat request: {question}")
        
        # Bedrock Knowledge Base를 통한 답변 생성 (references 포함)
        response = retrieve_and_generate_with_references(question)
        
        answer = response.get("output", {}).get("text", "답변을 생성할 수 없습니다")
        citations = response.get("citations", [])
        
        logger.info(f"Retrieved {len(citations)} citations")
        
        # 출처 정보 추출 (S3에서 원본 파일 읽어서 메타데이터 추출)
        sources = []
        processed_locations = set()  # 중복 처리 방지
        
        logger.info(f"=== DEBUG: Full Bedrock response structure ===")
        logger.info(f"Citations count: {len(citations)}")
        
        for i, citation in enumerate(citations):
            logger.info(f"=== Processing citation {i} ===")
            logger.info(f"Citation structure: {json.dumps(citation, default=str, ensure_ascii=False)}")
            
            retrieved_refs = citation.get("retrievedReferences", [])
            logger.info(f"Retrieved references count: {len(retrieved_refs)}")
            
            for j, reference in enumerate(retrieved_refs):
                logger.info(f"=== Processing reference {j} ===")
                logger.info(f"Reference structure: {json.dumps(reference, default=str, ensure_ascii=False)}")
                
                content = reference.get("content", {}).get("text", "")
                location = reference.get("location", {})
                
                logger.info(f"Content length: {len(content)}")
                logger.info(f"Location structure: {json.dumps(location, default=str, ensure_ascii=False)}")
                
                # S3 location에서 URI 추출
                s3_location = location.get("s3Location", {})
                s3_uri = s3_location.get("uri", "")
                
                logger.info(f"Extracted S3 URI: '{s3_uri}'")
                
                if s3_uri and s3_uri not in processed_locations:
                    processed_locations.add(s3_uri)
                    
                    # S3에서 원본 파일을 읽어 최적의 기사 메타데이터 추출
                    try:
                        metadata = find_best_matching_article(s3_uri, content)
                        logger.info(f"Metadata extraction result: {metadata}")
                        
                        if metadata and metadata.get("title"):
                            source_info = {
                                "title": metadata["title"],
                                "date": metadata["date"] or "날짜 없음", 
                                "author": metadata["author"],
                                "media": metadata["media"],
                                "url": metadata["url"],
                                "s3_uri": s3_uri
                            }
                            sources.append(source_info)
                            logger.info(f"✅ Successfully added source: {source_info}")
                        else:
                            logger.warning(f"❌ No valid metadata extracted from {s3_uri}")
                    except Exception as e:
                        logger.error(f"❌ Error extracting metadata from {s3_uri}: {str(e)}")
                else:
                    if not s3_uri:
                        logger.warning(f"❌ Empty S3 URI in reference {j}")
                        logger.info(f"Raw location data: {location}")
                    else:
                        logger.info(f"🔄 S3 URI already processed: {s3_uri}")
        
        logger.info(f"=== FINAL SOURCES COUNT: {len(sources)} ===")
        for idx, source in enumerate(sources):
            logger.info(f"Source {idx}: {source}")
        
        # 최대 5개 출처만 사용
        top_sources = sources[:5]
        
        # 답변에 각주가 없으면 추가
        footnoted_answer = answer
        if not re.search(r'\[\d+\]', answer) and top_sources:
            footnoted_answer = add_footnotes_to_answer(answer, top_sources)
        
        result = {
            "answer": footnoted_answer,
            "sources": top_sources,
            "question": question,
            "timestamp": response.get("sessionId", "")
        }
        
        logger.info(f"Generated response with {len(top_sources)} sources")
        
        # API Gateway 응답 형식
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type, Authorization"
            },
            "body": json.dumps(result, ensure_ascii=False)
        }
        
    except ChatbotError as e:
        logger.warning(f"Chatbot error: {str(e)}")
        return {
            "statusCode": 400,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({
                "error": str(e),
                "type": "validation_error"
            }, ensure_ascii=False)
        }
        
    except Exception as e:
        logger.error(f"Unexpected error in handle_chat: {str(e)}")
        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({
                "error": "서버 내부 오류가 발생했습니다",
                "type": "internal_error"
            }, ensure_ascii=False)
        }


def health_check(event: Dict[str, Any]) -> Dict[str, Any]:
    """헬스 체크 엔드포인트"""
    try:
        if not KNOWLEDGE_BASE_ID:
            return {
                "statusCode": 500,
                "headers": {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*"
                },
                "body": json.dumps({
                    "status": "unhealthy",
                    "message": "Knowledge Base ID가 설정되지 않았습니다"
                }, ensure_ascii=False)
            }
        
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({
                "status": "healthy",
                "service": "news-chatbot-simple",
                "knowledge_base_id": KNOWLEDGE_BASE_ID,
                "version": "1.0.0"
            }, ensure_ascii=False)
        }
        
    except Exception as e:
        logger.error(f"Health check failed: {str(e)}")
        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({
                "status": "unhealthy",
                "error": str(e)
            }, ensure_ascii=False)
        }


def lambda_handler(event: Dict[str, Any], context) -> Dict[str, Any]:
    """Lambda 함수의 메인 핸들러"""
    logger.info(f"Processing request: {json.dumps(event, default=str)}")
    
    try:
        # HTTP 메서드와 경로에 따라 라우팅
        http_method = event.get("httpMethod", "POST")
        path = event.get("path", "/chat")
        
        if http_method == "OPTIONS":
            # CORS preflight 요청 처리
            return {
                "statusCode": 200,
                "headers": {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
                    "Access-Control-Allow-Headers": "Content-Type, Authorization"
                },
                "body": ""
            }
        elif path == "/health" or path.endswith("/health"):
            return health_check(event)
        elif path == "/chat" or path.endswith("/chat"):
            return handle_chat(event)
        else:
            return {
                "statusCode": 404,
                "headers": {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*"
                },
                "body": json.dumps({
                    "error": "Not Found",
                    "message": f"Path {path} not found"
                }, ensure_ascii=False)
            }
            
    except Exception as e:
        logger.error(f"Unhandled error in lambda handler: {str(e)}")
        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({
                "error": "서버 내부 오류가 발생했습니다",
                "type": "internal_error"
            }, ensure_ascii=False)
        }


# 하위 호환성을 위한 별칭
handler = lambda_handler